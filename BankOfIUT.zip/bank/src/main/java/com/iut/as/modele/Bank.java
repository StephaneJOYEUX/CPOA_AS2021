package com.iut.as.modele;

public class Bank {

}

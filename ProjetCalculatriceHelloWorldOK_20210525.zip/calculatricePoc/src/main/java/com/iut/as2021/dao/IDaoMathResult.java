package com.iut.as2021.dao;

import com.iut.as2021.metier.MathResultat;

public interface IDaoMathResult extends IDao<MathResultat> {

}

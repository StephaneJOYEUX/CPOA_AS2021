package com.iut.as2021.enumerations;

public enum EDirection {
	GAUCHE, DROITE, INIT
}

package com.iut.as2021.dao;

public enum ETypeDao {
	MYSQL, ORACLE, XML, FILE
}

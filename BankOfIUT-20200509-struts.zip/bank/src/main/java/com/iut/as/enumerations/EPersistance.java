package com.iut.as.enumerations;

/***
 * Type de persistances possibles :
 * 
 * @author stephane.joyeux
 *
 */
public enum EPersistance {
	MEMOIRE, MYSQL
}
